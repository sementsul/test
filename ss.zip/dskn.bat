﻿
@echo off
Setlocal EnableDelayedExpansion EnableExtensions
 
set disknum=%1
Call :GetPartition "\\.\PHYSICALDRIVE%disknum%" Drives
echo %Drives% > temp.txt
 
goto :eof
 
::Конвертация PhysicalDrive Name -> Partition Names -> Drive Names
  :GetPartition %1.in-PhysicalDrive_Name %2-out.Drive_Names
  Set "%~2="
  For /F "skip=2 delims==, tokens=3,6-7" %%i In (
    'WMIC path Win32_DiskDriveToDiskPartition get /format:csv'
  ) do (
    if %%i=="%~1" (
      For /F "skip=2 delims==, tokens=3-4,7" %%I In (
        'WMIC path Win32_LogicalDiskToPartition get Antecedent^,Dependent /format:csv'
      ) do (
        if "%%I,%%J"=="%%j,%%k" Set "%~2=!%~2! %%K"
  )))


