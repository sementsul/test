@echo off
echo %1
powershell -Command "Invoke-WebRequest https://sementsul.ru/count.php?metrica=open

if "%2"=="WEB" goto web
echo Test > %2\tdd.txt

Echo Testing disk, and installing mbr
find "Test" < "%2\tdd.txt" || goto err
dskn.exe 1
find "%2" < temp.txt || goto d2
MSDOSBOOT.exe DRIVE=1 MSDOS CHS VOLUME dos
goto inst


:d2
dskn.exe 2
find "%2" < temp.txt || goto d3
MSDOSBOOT.exe DRIVE=2 MSDOS CHS VOLUME dos
goto inst

:d3
dskn.exe 3
find "%2" < temp.txt || goto d4
MSDOSBOOT.exe DRIVE=3 MSDOS CHS VOLUME dos
goto inst


:d4
dskn.exe 4
find "%2" < temp.txt || goto d5
MSDOSBOOT.exe DRIVE=4 MSDOS CHS VOLUME dos
goto inst


:d5
dskn.exe 5
find "%2" < temp.txt || goto d6
MSDOSBOOT.exe DRIVE=5 MSDOS CHS VOLUME dos
goto inst


:d6
dskn.exe 6
find "%2" < temp.txt || goto d7
MSDOSBOOT.exe DRIVE=6 MSDOS CHS VOLUME dos
goto inst

:d7
dskn.exe 7
find "%2" < temp.txt || goto d8
MSDOSBOOT.exe DRIVE=7 MSDOS CHS VOLUME dos
goto inst

:d8
dskn.exe 8
find "%2" < temp.txt || goto d9
MSDOSBOOT.exe DRIVE=8 MSDOS CHS VOLUME dos
goto inst

:d9
dskn.exe 9
find "%2" < temp.txt || goto d10
MSDOSBOOT.exe DRIVE=9 MSDOS CHS VOLUME dos
goto inst

:d10
dskn.exe 10
find "%2" < temp.txt || goto d11
MSDOSBOOT.exe DRIVE=10 MSDOS CHS VOLUME dos
goto inst

:d11
dskn.exe 11
find "%2" < temp.txt || goto d12
MSDOSBOOT.exe DRIVE=11 MSDOS CHS VOLUME dos
goto inst


:d12
dskn.exe 12
find "%2" < temp.txt || goto d13
MSDOSBOOT.exe DRIVE=12 MSDOS CHS VOLUME dos
goto inst

:d13
dskn.exe 13
find "%2" < temp.txt || goto d14
MSDOSBOOT.exe DRIVE=13 MSDOS CHS VOLUME dos
goto inst


:d14
dskn.exe 14
find "%2" < temp.txt || goto d15
MSDOSBOOT.exe DRIVE=14 MSDOS CHS VOLUME dos
goto inst

:d15
dskn.exe 15
find "%2" < temp.txt || goto d16
MSDOSBOOT.exe DRIVE=15 MSDOS CHS VOLUME dos
goto inst


:d16
dskn.exe 16
find "%2" < temp.txt || goto d17
MSDOSBOOT.exe DRIVE=16 MSDOS CHS VOLUME dos
goto inst


:d17
dskn.exe 17
find "%2" < temp.txt || goto d18
MSDOSBOOT.exe DRIVE=17 MSDOS CHS VOLUME dos
goto inst


:d18
dskn.exe 18
find "%2" < temp.txt || goto d19
MSDOSBOOT.exe DRIVE=18 MSDOS CHS VOLUME dos
goto inst


:d19
dskn.exe 19
find "%2" < temp.txt || goto d20
MSDOSBOOT.exe DRIVE=19 MSDOS CHS VOLUME dos
goto inst

:d20
dskn.exe 20
find "%2" < temp.txt || goto d21
MSDOSBOOT.exe DRIVE=20 MSDOS CHS VOLUME dos
goto inst

:d21
dskn.exe 21
find "%2" < temp.txt || goto d22
MSDOSBOOT.exe DRIVE=21 MSDOS CHS VOLUME dos
goto inst

:d22
dskn.exe 22
find "%2" < temp.txt || goto d23
MSDOSBOOT.exe DRIVE=22 MSDOS CHS VOLUME dos
goto inst

:d23
dskn.exe 23
find "%2" < temp.txt || goto d24
MSDOSBOOT.exe DRIVE=23 MSDOS CHS VOLUME dos
goto inst

:d24
dskn.exe 24
find "%2" < temp.txt || goto d25
MSDOSBOOT.exe DRIVE=24 MSDOS CHS VOLUME dos
goto inst

:d25
dskn.exe 25
find "%2" < temp.txt || goto d26
MSDOSBOOT.exe DRIVE=25 MSDOS CHS VOLUME dos
goto inst

:d26
dskn.exe 26
find "%2" < temp.txt || goto d27
MSDOSBOOT.exe DRIVE=26 MSDOS CHS VOLUME dos
goto inst

:d27
dskn.exe 27
find "%2" < temp.txt || goto d28
MSDOSBOOT.exe DRIVE=27 MSDOS CHS VOLUME dos
goto inst

:d28
dskn.exe 28
find "%2" < temp.txt || goto d29
MSDOSBOOT.exe DRIVE=28 MSDOS CHS VOLUME dos
goto inst


:d29
dskn.exe 29
find "%2" < temp.txt || goto d30
MSDOSBOOT.exe DRIVE=29 MSDOS CHS VOLUME dos
goto inst

:d30
dskn.exe 30
find "%2" < temp.txt || goto err
MSDOSBOOT.exe DRIVE=30 MSDOS CHS VOLUME dos
goto inst

:err
Echo Disk error!
echo Error %ERRORLEVEL%
powershell -Command "Invoke-WebRequest https://sementsul.ru/count.php?err=err
exit 

:web
powershell -Command "Invoke-WebRequest https://sementsul.ru/count.php?metrica=web
if "%1"=="/MSD5" start explorer https://sementsul.ru/
if "%1"=="/MSD6" start explorer https://sementsul.ru/
exit 

:inst
if not "%ERRORLEVEL%"=="0" goto err

Echo copiring files
type cfg.conf > dosbox.conf
echo mount d %2\ >> dosbox.conf
if "%1"=="/MSD5" dosbox.exe DOS\msd5s.BAT
if "%1"=="/MSD5" powershell -Command "Invoke-WebRequest https://sementsul.ru/count.php?metrica=msd5


if "%1"=="/MSD6" dosbox.exe DOS\msd6s.BAT
if "%1"=="/MSD6" powershell -Command "Invoke-WebRequest https://sementsul.ru/count.php?metrica=msd6




if not "%ERRORLEVEL%"=="0" goto err





